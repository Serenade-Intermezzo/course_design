# DIP_coursedesign > 2025-12-16 4:43pm
https://universe.roboflow.com/dipproject-agpcb/dip_coursedesign

Provided by a Roboflow user
License: CC BY 4.0

